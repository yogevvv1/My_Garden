﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace My_Garden
{

    public partial class start_game : Form
    {
        int clickED = 0, clickBT = 0, clickFl = 0;  // משתני בקרה ללחצנים לדעת אם הם לחוצים או לא
        garden myG = new garden();
        int e1 = 0, e2 = 0, b1 = 0, b2 = 0, f1 = 0, f2 = 0;


        private void button7_Click(object sender, EventArgs e)
        {
            int a, index;
            if (ed1rd.Checked) { a = 1; }
            else { a = 2; }
            index = myG.searchPlanetByName("beauti tree" + a.ToString());
            if (index < 0 || index >= myG.CountOfPlants()) { MessageBox.Show("Eror"); }
            else if (0 <= index&&myG.getPlant(index).Planet_is_Ready() == true)
            {
                if (myG.getPlant(index).pick() == false) { MessageBox.Show("you already picked"); }
                else { MessageBox.Show("the Leaves picked Succeeded"); }
            }
            else { MessageBox.Show("the Tree need more water"); }
        }

        private void button3_Click(object sender, EventArgs e)
        {//מחיקת פרח
            int a, index;
            if (f1rd.Checked) { a = 1; }
            else { a = 2; }
            index = myG.searchPlanetByName("flower" + a.ToString());
            if (index < 0 || index >= myG.CountOfPlants()) { MessageBox.Show("Eror"); }
            else if (0 <= index&&myG.getPlant(index).checkIfCanPick() == true)
            {
                myG.destroyPlanet(index);

                { MessageBox.Show("the prune Succeeded"); }
            }

            else { MessageBox.Show("the Flower need more water"); }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int a, index;
            if (ed1rd.Checked) { a = 1; }
            else { a = 2; }
            index = myG.searchPlanetByName("edible tree" + a.ToString());
            if (index < 0 || index >= myG.CountOfPlants()) { MessageBox.Show("Eror"); }
            else if (0 <= index&&myG.getPlant(index).Planet_is_Ready() == true)
            {
                if (myG.getPlant(index).pick() == false) { MessageBox.Show("you already picked"); }
                else { MessageBox.Show("the picked Succeeded"); }
            }
            else { MessageBox.Show("the Tree need more water"); }
        }

        private void saveButtom_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.InitialDirectory = Directory.GetCurrentDirectory();// + "..\\myModels";
            saveFileDialog1.Filter = "model files (*.mdl)|*.mdl|All files (*.*)|*.*";
            saveFileDialog1.FilterIndex = 1;
            saveFileDialog1.RestoreDirectory = true;
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                IFormatter formatter = new BinaryFormatter();
                using (Stream stream = new FileStream(saveFileDialog1.FileName, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    //!!!!
                    formatter.Serialize(stream, myG);
                }
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {//גזימת ענפים
            int a, index;
            if (ed1rd.Checked) { a = 1; }
            else { a = 2; }
            index = myG.searchPlanetByName("edible tree" + a.ToString());
            if (index < 0 || index >= myG.CountOfPlants()) { MessageBox.Show("Eror"); }
            else if (0<=index&&myG.getPlant(index).Planet_is_Ready() == true)
            {
                if (myG.getPlant(index).prune() == false) { MessageBox.Show("you already pruned"); }
                else
                {
                    MessageBox.Show("the prune Succeeded");
                    switch (a)
                    {
                        //case 1: { planet1.Image = imageList2.Images[f1 - 1]; break; }
                        //case 2: { planet4.Image = imageList2.Images[f2 - 1]; break; }
                    }
                }
            }
            else { MessageBox.Show("the Tree need more water"); }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            {//גזימת ענפים
                int a, index;
                if (btrd1.Checked) { a = 1; }
                else { a = 2; }
                index = myG.searchPlanetByName("beauti tree" + a.ToString());
                if (index < 0 || index >= myG.CountOfPlants()) { MessageBox.Show("Eror"); }
                else if (0<=index&&myG.getPlant(index).Planet_is_Ready() == true)
                {
                    if (myG.getPlant(index).prune() == false) { MessageBox.Show("you already pruned"); }
                    else
                    {
                        MessageBox.Show("the prune Succeeded");
                        switch (a)
                        {
                            //case 1: { planet1.Image = imageList2.Images[f1 - 1]; break; }
                            //case 2: { planet4.Image = imageList2.Images[f2 - 1]; break; }
                        }
                    }
                }
                else { MessageBox.Show("the Tree need more water"); }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {//גזימת קוצים
            int a, index;
            if (f1rd.Checked) { a = 1; }
            else { a = 2; }
            index = myG.searchPlanetByName("flower" + a.ToString());
            if (index < 0 || index >= myG.CountOfPlants()) { MessageBox.Show("Eror"); }
            else if (0<=index&&myG.getPlant(index).Planet_is_Ready() == true)
            {
                if (myG.getPlant(index).prune() == false) { MessageBox.Show("you already pruned"); }
                else
                {
                    MessageBox.Show("the prune Succeeded");
                    switch (a)
                    {
                        case 1: { planet1.Image = imageList2.Images[f1 - 1]; break; }
                        case 2: { planet4.Image = imageList2.Images[f2 - 1]; break; }
                    }
                }
            }
            else { MessageBox.Show("the Flower need more water"); }
        }

        public start_game()
        {
            InitializeComponent();
        }
        //*
        private void CET_Click(object sender, EventArgs e)
        {
            if (clickED == 0)
            {
                myG.addPlanet(0);
                planet2.Image = imageList1.Images[0];
            }
            if (clickED == 1)
            {
                myG.addPlanet(0);
                planet5.Image = imageList1.Images[0];
            }
            if (clickED > 1)
                MessageBox.Show("The trees are not ready.\n please water them");
            clickED++;

        }

        private void CBT_Click(object sender, EventArgs e)
        {
            if (clickBT == 0)
            {
                myG.addPlanet(1);
                planet3.Image = imageList3.Images[0];
            }
            if (clickBT == 1)
            {
                myG.addPlanet(1);
                planet6.Image = imageList3.Images[0];
            }
            if (clickBT > 1)
                MessageBox.Show("The trees are not ready.\n please water them");
            clickBT++;
        }

        private void CF_Click(object sender, EventArgs e)
        {

            if (clickFl == 0)
            {
                f1 = 0;
                myG.addPlanet(2);
                planet1.Image = imageList2.Images[0];
            }
            if (clickFl == 1)
            {
                f2 = 0;
                myG.addPlanet(2);
                planet4.Image = imageList2.Images[0];
            }
            if (clickFl > 1)
                MessageBox.Show("The Flowers are not ready.\n please water them");
            clickFl++;
        }


        private void button1_Click(object sender, EventArgs e)
        {//כפתור השקיה
            int a = int.Parse(planetChoise.Text), index;
            string name;
            if (edrd.Checked) { name = "edible tree"; }
            else if (btrd.Checked) { name = "beauti tree"; }
            else { name = "flower"; }
            name = name + a.ToString();
            index = myG.searchPlanetByName(name);//האינדקס שבמערך הצמחים
            if (index < 0 || index >= myG.CountOfPlants()) { MessageBox.Show("Eror"); }
           else if (0<=index&&myG.getPlant(index).Planet_is_Ready() == true)
            {
                myG.getPlant(index).make_Plant_Ready();
                MessageBox.Show(name + " has a full amount of water");
                return;
            }

            else
            {
                myG.getPlant(index).Water_a_plant();
                switch (name)
                {
                    case "flower1": { planet1.Image = imageList2.Images[++f1]; break; }
                    case "flower2": { planet4.Image = imageList2.Images[++f2]; break; }
                    case "edible tree1": { planet2.Image = imageList1.Images[++e1]; break; }
                    case "edible tree2": { planet5.Image = imageList1.Images[++e2]; break; }
                    case "beauti tree1": { planet3.Image = imageList3.Images[++b1]; break; }
                    case "beauti tree2": { planet6.Image = imageList3.Images[++b2]; break; }
                }
                if (myG.getPlant(index).Planet_is_Ready() == true) { myG.getPlant(index).make_Plant_Ready(); }
                return;
            }
            MessageBox.Show("you choose wrong planet");
        }
    
            
                
                private void start_game_Load(object sender, EventArgs e)
            {

            }
        }
    }


    


