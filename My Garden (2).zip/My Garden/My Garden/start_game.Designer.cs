﻿
namespace My_Garden
{
    partial class start_game
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(start_game));
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button9 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.btrd2 = new System.Windows.Forms.RadioButton();
            this.btrd1 = new System.Windows.Forms.RadioButton();
            this.button7 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.CF = new System.Windows.Forms.Button();
            this.CET = new System.Windows.Forms.Button();
            this.CBT = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button8 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.ed2rd = new System.Windows.Forms.RadioButton();
            this.ed1rd = new System.Windows.Forms.RadioButton();
            this.button5 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.f2rd = new System.Windows.Forms.RadioButton();
            this.f1rd = new System.Windows.Forms.RadioButton();
            this.button2 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.edrd = new System.Windows.Forms.RadioButton();
            this.btrd = new System.Windows.Forms.RadioButton();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.planetChoise = new System.Windows.Forms.TextBox();
            this.flrd = new System.Windows.Forms.RadioButton();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.planet1 = new System.Windows.Forms.PictureBox();
            this.planet2 = new System.Windows.Forms.PictureBox();
            this.planet4 = new System.Windows.Forms.PictureBox();
            this.planet5 = new System.Windows.Forms.PictureBox();
            this.planet3 = new System.Windows.Forms.PictureBox();
            this.planet6 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.imageList2 = new System.Windows.Forms.ImageList(this.components);
            this.imageList3 = new System.Windows.Forms.ImageList(this.components);
            this.saveButtom = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.planet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.planet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.planet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.planet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.planet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.planet6)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Controls.Add(this.CF);
            this.panel1.Controls.Add(this.CET);
            this.panel1.Controls.Add(this.CBT);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Location = new System.Drawing.Point(851, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(321, 1016);
            this.panel1.TabIndex = 2;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button9);
            this.groupBox4.Controls.Add(this.button6);
            this.groupBox4.Controls.Add(this.btrd2);
            this.groupBox4.Controls.Add(this.btrd1);
            this.groupBox4.Controls.Add(this.button7);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Location = new System.Drawing.Point(3, 731);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(317, 149);
            this.groupBox4.TabIndex = 17;
            this.groupBox4.TabStop = false;
            // 
            // button9
            // 
            this.button9.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar;
            this.button9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button9.Font = new System.Drawing.Font("Segoe Print", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(214, 102);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(89, 41);
            this.button9.TabIndex = 20;
            this.button9.Text = "prune";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button6
            // 
            this.button6.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar;
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button6.Font = new System.Drawing.Font("Segoe Print", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(105, 102);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(89, 41);
            this.button6.TabIndex = 18;
            this.button6.Text = "Destroy tree";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // btrd2
            // 
            this.btrd2.AutoSize = true;
            this.btrd2.Location = new System.Drawing.Point(178, 60);
            this.btrd2.Name = "btrd2";
            this.btrd2.Size = new System.Drawing.Size(129, 24);
            this.btrd2.TabIndex = 17;
            this.btrd2.TabStop = true;
            this.btrd2.Text = "Beauti Tree 2";
            this.btrd2.UseVisualStyleBackColor = true;
            // 
            // btrd1
            // 
            this.btrd1.AutoSize = true;
            this.btrd1.Location = new System.Drawing.Point(17, 60);
            this.btrd1.Name = "btrd1";
            this.btrd1.Size = new System.Drawing.Size(129, 24);
            this.btrd1.TabIndex = 16;
            this.btrd1.TabStop = true;
            this.btrd1.Text = "Beauti Tree 1";
            this.btrd1.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar;
            this.button7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button7.Font = new System.Drawing.Font("Segoe Print", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(0, 102);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(79, 41);
            this.button7.TabIndex = 14;
            this.button7.Text = "Pick the Leaves";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label10.Location = new System.Drawing.Point(56, 22);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(214, 22);
            this.label10.TabIndex = 15;
            this.label10.Text = "Beauti Tree opstions : ";
            // 
            // CF
            // 
            this.CF.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar;
            this.CF.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CF.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.CF.Font = new System.Drawing.Font("Segoe Print", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CF.Location = new System.Drawing.Point(39, 82);
            this.CF.Name = "CF";
            this.CF.Size = new System.Drawing.Size(175, 47);
            this.CF.TabIndex = 5;
            this.CF.Text = "Create Flower";
            this.CF.UseVisualStyleBackColor = true;
            this.CF.Click += new System.EventHandler(this.CF_Click);
            // 
            // CET
            // 
            this.CET.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar;
            this.CET.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CET.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.CET.Font = new System.Drawing.Font("Segoe Print", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CET.Location = new System.Drawing.Point(9, 22);
            this.CET.Name = "CET";
            this.CET.Size = new System.Drawing.Size(179, 54);
            this.CET.TabIndex = 4;
            this.CET.Text = "Create Edible Tree";
            this.CET.UseVisualStyleBackColor = true;
            this.CET.Click += new System.EventHandler(this.CET_Click);
            // 
            // CBT
            // 
            this.CBT.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar;
            this.CBT.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CBT.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.CBT.Font = new System.Drawing.Font("Segoe Print", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBT.Location = new System.Drawing.Point(79, 137);
            this.CBT.Name = "CBT";
            this.CBT.Size = new System.Drawing.Size(175, 58);
            this.CBT.TabIndex = 6;
            this.CBT.Text = "Create Beauti Tree";
            this.CBT.UseVisualStyleBackColor = true;
            this.CBT.Click += new System.EventHandler(this.CBT_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button8);
            this.groupBox3.Controls.Add(this.button4);
            this.groupBox3.Controls.Add(this.ed2rd);
            this.groupBox3.Controls.Add(this.ed1rd);
            this.groupBox3.Controls.Add(this.button5);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Location = new System.Drawing.Point(9, 562);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(317, 149);
            this.groupBox3.TabIndex = 16;
            this.groupBox3.TabStop = false;
            // 
            // button8
            // 
            this.button8.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar;
            this.button8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button8.Font = new System.Drawing.Font("Segoe Print", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(208, 102);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(89, 41);
            this.button8.TabIndex = 19;
            this.button8.Text = "prune";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button4
            // 
            this.button4.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button4.Font = new System.Drawing.Font("Segoe Print", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(99, 102);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(89, 41);
            this.button4.TabIndex = 18;
            this.button4.Text = "Destroy tree";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // ed2rd
            // 
            this.ed2rd.AutoSize = true;
            this.ed2rd.Location = new System.Drawing.Point(178, 60);
            this.ed2rd.Name = "ed2rd";
            this.ed2rd.Size = new System.Drawing.Size(127, 24);
            this.ed2rd.TabIndex = 17;
            this.ed2rd.TabStop = true;
            this.ed2rd.Text = "Edible Tree 2";
            this.ed2rd.UseVisualStyleBackColor = true;
            // 
            // ed1rd
            // 
            this.ed1rd.AutoSize = true;
            this.ed1rd.Location = new System.Drawing.Point(17, 60);
            this.ed1rd.Name = "ed1rd";
            this.ed1rd.Size = new System.Drawing.Size(127, 24);
            this.ed1rd.TabIndex = 16;
            this.ed1rd.TabStop = true;
            this.ed1rd.Text = "Edible Tree 1";
            this.ed1rd.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar;
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button5.Font = new System.Drawing.Font("Segoe Print", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(6, 102);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(67, 47);
            this.button5.TabIndex = 14;
            this.button5.Text = "Pick the Fruite";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label9.Location = new System.Drawing.Point(56, 22);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(213, 22);
            this.label9.TabIndex = 15;
            this.label9.Text = "Edible Tree opstions : ";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.f2rd);
            this.groupBox2.Controls.Add(this.f1rd);
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Location = new System.Drawing.Point(3, 407);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(317, 149);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            // 
            // button3
            // 
            this.button3.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.Font = new System.Drawing.Font("Segoe Print", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(167, 102);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(144, 41);
            this.button3.TabIndex = 18;
            this.button3.Text = "Pick Flower";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // f2rd
            // 
            this.f2rd.AutoSize = true;
            this.f2rd.Location = new System.Drawing.Point(175, 60);
            this.f2rd.Name = "f2rd";
            this.f2rd.Size = new System.Drawing.Size(94, 24);
            this.f2rd.TabIndex = 17;
            this.f2rd.TabStop = true;
            this.f2rd.Text = "Flower 2";
            this.f2rd.UseVisualStyleBackColor = true;
            // 
            // f1rd
            // 
            this.f1rd.AutoSize = true;
            this.f1rd.Location = new System.Drawing.Point(50, 60);
            this.f1rd.Name = "f1rd";
            this.f1rd.Size = new System.Drawing.Size(94, 24);
            this.f1rd.TabIndex = 16;
            this.f1rd.TabStop = true;
            this.f1rd.Text = "Flower 1";
            this.f1rd.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("Segoe Print", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(6, 102);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(144, 41);
            this.button2.TabIndex = 14;
            this.button2.Text = "Pick the thorns";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label8.Location = new System.Drawing.Point(87, 18);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(169, 22);
            this.label8.TabIndex = 15;
            this.label8.Text = "Flower opstions : ";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.edrd);
            this.groupBox1.Controls.Add(this.btrd);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.planetChoise);
            this.groupBox1.Controls.Add(this.flrd);
            this.groupBox1.Location = new System.Drawing.Point(15, 201);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(268, 200);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            // 
            // edrd
            // 
            this.edrd.AutoSize = true;
            this.edrd.Location = new System.Drawing.Point(179, 116);
            this.edrd.Name = "edrd";
            this.edrd.Size = new System.Drawing.Size(78, 24);
            this.edrd.TabIndex = 11;
            this.edrd.TabStop = true;
            this.edrd.Text = "Edible";
            this.edrd.UseVisualStyleBackColor = true;
            // 
            // btrd
            // 
            this.btrd.AutoSize = true;
            this.btrd.Location = new System.Drawing.Point(93, 116);
            this.btrd.Name = "btrd";
            this.btrd.Size = new System.Drawing.Size(80, 24);
            this.btrd.TabIndex = 12;
            this.btrd.TabStop = true;
            this.btrd.Text = "Beauti";
            this.btrd.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Segoe Print", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(44, 151);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(175, 35);
            this.button1.TabIndex = 7;
            this.button1.Text = "Water A Plant";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(230, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "witch planet you want to water?";
            // 
            // planetChoise
            // 
            this.planetChoise.Location = new System.Drawing.Point(105, 73);
            this.planetChoise.Name = "planetChoise";
            this.planetChoise.Size = new System.Drawing.Size(43, 26);
            this.planetChoise.TabIndex = 9;
            // 
            // flrd
            // 
            this.flrd.AutoSize = true;
            this.flrd.Location = new System.Drawing.Point(6, 116);
            this.flrd.Name = "flrd";
            this.flrd.Size = new System.Drawing.Size(81, 24);
            this.flrd.TabIndex = 10;
            this.flrd.TabStop = true;
            this.flrd.Text = "Flower";
            this.flrd.UseVisualStyleBackColor = true;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "1.png");
            this.imageList1.Images.SetKeyName(1, "2.png");
            this.imageList1.Images.SetKeyName(2, "3.png");
            this.imageList1.Images.SetKeyName(3, "4.png");
            this.imageList1.Images.SetKeyName(4, "5.png");
            this.imageList1.Images.SetKeyName(5, "6.png");
            this.imageList1.Images.SetKeyName(6, "7.png");
            // 
            // planet1
            // 
            this.planet1.BackColor = System.Drawing.Color.Transparent;
            this.planet1.Location = new System.Drawing.Point(58, 114);
            this.planet1.Name = "planet1";
            this.planet1.Size = new System.Drawing.Size(120, 84);
            this.planet1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.planet1.TabIndex = 3;
            this.planet1.TabStop = false;
            // 
            // planet2
            // 
            this.planet2.BackColor = System.Drawing.Color.Transparent;
            this.planet2.Location = new System.Drawing.Point(329, 114);
            this.planet2.Name = "planet2";
            this.planet2.Size = new System.Drawing.Size(120, 84);
            this.planet2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.planet2.TabIndex = 4;
            this.planet2.TabStop = false;
            // 
            // planet4
            // 
            this.planet4.BackColor = System.Drawing.Color.Transparent;
            this.planet4.Location = new System.Drawing.Point(58, 329);
            this.planet4.Name = "planet4";
            this.planet4.Size = new System.Drawing.Size(120, 84);
            this.planet4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.planet4.TabIndex = 5;
            this.planet4.TabStop = false;
            // 
            // planet5
            // 
            this.planet5.BackColor = System.Drawing.Color.Transparent;
            this.planet5.Location = new System.Drawing.Point(329, 329);
            this.planet5.Name = "planet5";
            this.planet5.Size = new System.Drawing.Size(120, 84);
            this.planet5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.planet5.TabIndex = 6;
            this.planet5.TabStop = false;
            // 
            // planet3
            // 
            this.planet3.BackColor = System.Drawing.Color.Transparent;
            this.planet3.Location = new System.Drawing.Point(619, 114);
            this.planet3.Name = "planet3";
            this.planet3.Size = new System.Drawing.Size(129, 93);
            this.planet3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.planet3.TabIndex = 7;
            this.planet3.TabStop = false;
            // 
            // planet6
            // 
            this.planet6.BackColor = System.Drawing.Color.Transparent;
            this.planet6.Location = new System.Drawing.Point(619, 329);
            this.planet6.Name = "planet6";
            this.planet6.Size = new System.Drawing.Size(120, 84);
            this.planet6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.planet6.TabIndex = 8;
            this.planet6.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label2.Location = new System.Drawing.Point(74, 201);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 26);
            this.label2.TabIndex = 9;
            this.label2.Text = "Flower 1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label3.Location = new System.Drawing.Point(74, 425);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 26);
            this.label3.TabIndex = 10;
            this.label3.Text = "Flower 2";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label4.Location = new System.Drawing.Point(605, 416);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(154, 26);
            this.label4.TabIndex = 11;
            this.label4.Text = "Beauti Tree 2";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label5.Location = new System.Drawing.Point(614, 210);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(154, 26);
            this.label5.TabIndex = 12;
            this.label5.Text = "Beauti Tree 1";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label6.Location = new System.Drawing.Point(324, 416);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(153, 26);
            this.label6.TabIndex = 13;
            this.label6.Text = "Edible Tree 2";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label7.Location = new System.Drawing.Point(324, 201);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(153, 26);
            this.label7.TabIndex = 14;
            this.label7.Text = "Edible Tree 1";
            // 
            // imageList2
            // 
            this.imageList2.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList2.ImageStream")));
            this.imageList2.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList2.Images.SetKeyName(0, "f1fix.png");
            this.imageList2.Images.SetKeyName(1, "f2fix.png");
            this.imageList2.Images.SetKeyName(2, "f3fix.png");
            this.imageList2.Images.SetKeyName(3, "f4fix.png");
            this.imageList2.Images.SetKeyName(4, "f5fix.png");
            this.imageList2.Images.SetKeyName(5, "f6fix.png");
            // 
            // imageList3
            // 
            this.imageList3.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList3.ImageStream")));
            this.imageList3.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList3.Images.SetKeyName(0, "1.png");
            this.imageList3.Images.SetKeyName(1, "2.png");
            this.imageList3.Images.SetKeyName(2, "3.png");
            this.imageList3.Images.SetKeyName(3, "4.png");
            this.imageList3.Images.SetKeyName(4, "5.png");
            this.imageList3.Images.SetKeyName(5, "6.png");
            // 
            // saveButtom
            // 
            this.saveButtom.Location = new System.Drawing.Point(12, 22);
            this.saveButtom.Name = "saveButtom";
            this.saveButtom.Size = new System.Drawing.Size(86, 36);
            this.saveButtom.TabIndex = 15;
            this.saveButtom.Text = "save";
            this.saveButtom.UseVisualStyleBackColor = true;
            this.saveButtom.Click += new System.EventHandler(this.saveButtom_Click);
            // 
            // start_game
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1173, 1050);
            this.Controls.Add(this.saveButtom);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.planet6);
            this.Controls.Add(this.planet3);
            this.Controls.Add(this.planet5);
            this.Controls.Add(this.planet4);
            this.Controls.Add(this.planet2);
            this.Controls.Add(this.planet1);
            this.Controls.Add(this.panel1);
            this.DoubleBuffered = true;
            this.Name = "start_game";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "start_game";
            this.panel1.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.planet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.planet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.planet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.planet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.planet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.planet6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button CBT;
        private System.Windows.Forms.Button CF;
        private System.Windows.Forms.Button CET;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox planetChoise;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton btrd;
        private System.Windows.Forms.RadioButton flrd;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.PictureBox planet1;
        private System.Windows.Forms.PictureBox planet2;
        private System.Windows.Forms.PictureBox planet4;
        private System.Windows.Forms.PictureBox planet5;
        private System.Windows.Forms.PictureBox planet3;
        private System.Windows.Forms.PictureBox planet6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ImageList imageList2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton f2rd;
        private System.Windows.Forms.RadioButton f1rd;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.RadioButton ed2rd;
        private System.Windows.Forms.RadioButton ed1rd;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.RadioButton btrd2;
        private System.Windows.Forms.RadioButton btrd1;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ImageList imageList3;
        private System.Windows.Forms.Button saveButtom;
        private System.Windows.Forms.RadioButton edrd;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
    }
}