﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace My_Garden
{
    public partial class Form1 : Form
    {
        start_game st = new start_game();
        public Form1()
        {
            InitializeComponent();
        }

        private void SG_Click(object sender, EventArgs e)
        {
            st.Show();
        }
    }
}
